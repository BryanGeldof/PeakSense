# ⚡ PeakSense v0.4.0

**Intelligent Power Spike Detection & Device Recognition for Home Assistant**

Automatically detect which household device turned on based on its unique power consumption "fingerprint". PeakSense learns from your devices and recognizes them in real-time.

## 🎯 Features

✅ **Automatic Spike Detection** — Detects sudden power increases (800W threshold)  
✅ **Device Learning** — Train on real usage patterns  
✅ **Pattern Matching** — AI-based device recognition (peak, average, duration, shape)  
✅ **Confidence Scoring** — Know how sure the system is (0-100%)  
✅ **Standby Detection** — Auto-detect device standby power consumption  
✅ **Feedback Learning** — Improve accuracy by correcting detections  
✅ **REST API** — Full access to events, devices, and statistics  
✅ **SQLite Database** — Local storage, no cloud required  
✅ **Service Calls** — Integrate with any Home Assistant automation  

---

## 🚀 Quick Start

### 1. Install via HACS

```
HACS → Integrations → + Custom repositories
Repository: https://github.com/BryanGeldof/PeakSense
Category: Integration
→ Install → Restart HA
```

### 2. Add Integration

**Settings → Devices & Services → + Add Integration → PeakSense → Submit**

You'll now have 4 new sensors:
- `sensor.peaksense_last_event` — Last spike peak (W)
- `sensor.peaksense_status` — Spike detection status
- `sensor.peaksense_current_device` — Detected device name
- `sensor.peaksense_detection_confidence` — Confidence % (0-100)

### 3. Create Automation

Send power meter readings to PeakSense:

```yaml
alias: Feed power to PeakSense
trigger:
  - platform: state
    entity_id: sensor.YOUR_POWER_METER
action:
  - service: peaksense.update
    data:
      value: "{{ states('sensor.YOUR_POWER_METER') | float }}"
mode: queued
```

### 4. Register Devices

Start training the system:

```yaml
alias: Register Washing Machine
sequence:
  - service: peaksense.register_device
    data:
      name: "Washing Machine"
      standby_power: 2
      notes: "ASKO W6984, uses ~2000W peak"
```

### 5. Record Signatures

When a device runs, record its spike pattern:

```yaml
service: peaksense.record_signature
data:
  event_id: 1
  device_id: 1
```

Repeat 3-7 times for best accuracy.

---

## 🧠 How It Works

### Spike Detection
1. Power exceeds 800W → Spike **starts**
2. Values are recorded continuously
3. Power drops below 300W → Spike **ends**
4. Spike is saved with statistics:
   - Peak wattage
   - Average wattage
   - Duration (samples)
   - Variance (shape)

### Pattern Matching
The system compares each new spike against known device "signatures":

```
Event: peak=1900W, avg=1750W, duration=15s, variance=45
Device 1 (Washing Machine): peak=1950W, avg=1800W, duration=16s → 94% match
Device 2 (Oven): peak=2800W, avg=2700W, duration=45s → 12% match
→ Detected: Washing Machine (94% confidence)
```

### Learning
As you correct misdetections:
```yaml
service: peaksense.provide_feedback
data:
  event_id: 42
  device_id: 1
  is_correct: true  # Helps improve accuracy
```

---

## 📊 Services

### `peaksense.update`
Send a power value (in watts)
```yaml
service: peaksense.update
data:
  value: 1500
```

### `peaksense.register_device`
Register a new device for learning
```yaml
service: peaksense.register_device
data:
  name: "Coffee Machine"
  standby_power: 5
  notes: "Delonghi Magnifica"
```

### `peaksense.record_signature`
Record a spike as a device signature
```yaml
service: peaksense.record_signature
data:
  event_id: 42
  device_id: 1
```

### `peaksense.provide_feedback`
Train the model with user feedback
```yaml
service: peaksense.provide_feedback
data:
  event_id: 42
  device_id: 1
  is_correct: true
```

### `peaksense.update_device`
Change device settings
```yaml
service: peaksense.update_device
data:
  device_id: 1
  standby_power: 3
  notes: "Updated: now uses 3W standby"
```

### `peaksense.delete_device`
Remove a device
```yaml
service: peaksense.delete_device
data:
  device_id: 1
```

---

## 🔌 REST API

### GET `/api/peaksense/events`
Get all recent spike events
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://192.168.1.100:8123/api/peaksense/events
```

Response:
```json
[
  {
    "id": 42,
    "start": "2024-01-15T14:23:00",
    "end": "2024-01-15T14:23:05",
    "peak": 1900,
    "avg": 1750,
    "duration": 10,
    "variance": 45.2,
    "label": "unknown",
    "device_id": null,
    "confidence": 0.0
  }
]
```

### GET `/api/peaksense/devices`
Get all registered devices with statistics
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://192.168.1.100:8123/api/peaksense/devices
```

### GET `/api/peaksense/stats`
Get overall accuracy statistics
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://192.168.1.100:8123/api/peaksense/stats
```

---

## 📈 Training a Device

### Step 1: Register
```yaml
service: peaksense.register_device
data:
  name: "Washing Machine"
  standby_power: 2
```

### Step 2: Generate 3+ Spikes
Run the device 3-7 times and let PeakSense detect the spikes.

### Step 3: Record Signatures
For each spike, call:
```yaml
service: peaksense.record_signature
data:
  event_id: <spike_id>
  device_id: 1
```

### Step 4: Verify
Check `sensor.peaksense_current_device` — when the device runs, it should be detected automatically.

### Step 5: Improve
If detections are wrong, provide feedback:
```yaml
service: peaksense.provide_feedback
data:
  event_id: 42
  device_id: 1
  is_correct: false
```

---

## ⚙️ Configuration

Edit thresholds in `/custom_components/peaksense/const.py`:

```python
SPIKE_START_THRESHOLD = 800    # W (start detecting)
SPIKE_END_THRESHOLD = 300      # W (stop detecting)
MIN_CONFIDENCE = 0.75          # 75% required to auto-detect
MIN_SAMPLES_FOR_PATTERN = 3    # Need 3 spikes to learn
```

---

## 🎨 Dashboard Example

```yaml
type: vertical-stack
cards:
  - type: entities
    title: PeakSense Status
    entities:
      - sensor.peaksense_last_event
      - sensor.peaksense_status
      - sensor.peaksense_current_device
      - sensor.peaksense_detection_confidence

  - type: button
    name: Test 1000W
    action_type: call-service
    service: peaksense.update
    service_data:
      value: 1000

  - type: button
    name: Test 300W (end)
    action_type: call-service
    service: peaksense.update
    service_data:
      value: 300
```

---

## 📊 Database Schema

### events table
```sql
id, start, end, peak, avg, duration, variance, label, device_id, confidence
```

### devices table
```sql
id, name, standby_power, notes, created_at, updated_at
```

### signatures table
```sql
id, device_id, peak, avg, duration, variance, count
```

### detections table
```sql
id, event_id, device_id, confidence, is_correct
```

---

## 🆘 Troubleshooting

**No spikes detected?**
→ Check threshold values (default: 800W start, 300W end)
→ Verify automation is sending values to `peaksense.update`

**Detections not working?**
→ Need at least 3 recorded signatures per device
→ Check confidence: must be ≥75%
→ Check logs: Settings → System → Logs (search "peaksense")

**Wrong device detected?**
→ Use `peaksense.provide_feedback` to train the model
→ More signatures = better accuracy
→ Check standby power values

---

## 🎯 Accuracy Tips

1. **Record multiple spikes** — 5+ per device for best accuracy
2. **Vary the usage** — Different power levels help
3. **Correct mistakes** — Feedback improves the model
4. **Set standby power** — Helps distinguish devices
5. **Use descriptive names** — "Washing Machine" vs "Device 1"

---

## 📝 Event Example

```json
{
  "id": 42,
  "start": "2024-01-15T14:23:00.123456",
  "end": "2024-01-15T14:23:05.654321",
  "peak": 1900.5,
  "avg": 1750.2,
  "duration": 10,
  "variance": 45.2,
  "label": "unknown",
  "device_id": 1,
  "confidence": 0.94
}
```

**Attributes:**
- `peak` — Maximum wattage during spike
- `avg` — Average wattage during spike
- `duration` — Number of samples recorded
- `variance` — Spread/shape of the spike
- `confidence` — Match confidence (0-1)

---

## 🔮 Future Features

- 🧠 ML-based learning (decision trees)
- 📊 Historical analytics dashboard
- 🎛️ UI for device management
- 🌐 Multi-sensor support
- 📱 Mobile app integration
- 🔔 Notifications for unknown spikes

---

## 💡 Tips & Tricks

### Standby Detection Automation
```yaml
alias: Detect Standby Power
sequence:
  # Wait 1 minute after unplug
  - delay:
      minutes: 1
  # Record baseline (no device)
  - service: peaksense.update
    data:
      value: "{{ states('sensor.total_power') | float }}"
  # Wait 2 minutes
  - delay:
      minutes: 2
  # Plug device back in and repeat
```

### Batch Training
```yaml
alias: Train Multiple Devices
sequence:
  - service: peaksense.register_device
    data:
      name: "Device 1"
  - service: peaksense.register_device
    data:
      name: "Device 2"
  - service: peaksense.register_device
    data:
      name: "Device 3"
```

---

## 📜 License

MIT License — Feel free to use and modify!

---

## 🙏 Support

- 📖 Check this README
- 🐛 Report issues on GitHub
- 💬 Discussions welcome!

**Happy device detection!** ⚡
