# Changelog

## v0.4.0 — Intelligent Device Detection (Major Release)

### 🎯 New Features
- **AI-based Device Recognition** — Automatically detect which device is running based on power signature
- **Device Management** — Register, train, and manage household devices
- **Pattern Matching Engine** — Advanced similarity scoring (peak, average, duration, variance)
- **Feedback Learning** — Improve accuracy by correcting detections
- **Confidence Scoring** — Know how sure the system is (0-100%)
- **Device Statistics** — Track detection accuracy per device
- **REST API Expansion** — New endpoints for devices and statistics
- **New Sensors** — `sensor.peaksense_current_device` and `sensor.peaksense_detection_confidence`
- **Service Expansion** — 6 new services for full device management

### 🔧 Technical Improvements
- Complete database redesign (4 tables: events, devices, signatures, detections)
- Pattern matcher with multi-metric similarity scoring
- Improved spike detection with variance calculation
- Better error handling and logging

### 📊 Database Schema
```
events       — Detected spikes with device assignment
devices      — Registered household devices
signatures   — Device learning data (peaks, averages, durations)
detections   — Recognition results with confidence scores
```

### 📡 New Services
- `peaksense.register_device` — Add a new device
- `peaksense.record_signature` — Train on a spike
- `peaksense.provide_feedback` — Improve with feedback
- `peaksense.update_device` — Modify device info
- `peaksense.delete_device` — Remove a device
- Plus enhanced existing services

### 🆕 New REST Endpoints
- `GET /api/peaksense/devices` — List devices with stats
- `GET /api/peaksense/stats` — Overall accuracy statistics

### 🧪 Testing
- Full testing automation templates included
- Example automations for all workflows
- Comprehensive setup guide with troubleshooting

---

## v0.3.0 — HACS Support

### ✨ Features
- Custom Lovelace dashboard card
- HACS auto-update support
- Professional documentation

### 🐛 Fixes
- Fixed sensor registration
- Improved config flow

---

## v0.2.0 — Dashboard & HACS

### ✨ Features
- Custom dashboard card
- HACS integration support
- Improved documentation

### 🐛 Fixes
- Fixed missing sensors
- Fixed storage methods

---

## v0.1.0 — Initial Release

### ✨ Features
- Basic spike detection
- SQLite storage
- Service calls
- Manual event labeling

---

## Upgrading

### From v0.3.0 to v0.4.0
**No manual steps required!** HACS will update automatically.

After update:
1. Restart Home Assistant
2. New sensors will appear automatically
3. Your existing spike data is preserved
4. Start registering devices using new services

### Breaking Changes
None — fully backwards compatible!

---

## Known Limitations

- Thresholds are hardcoded (adjust in `const.py` if needed)
- Pattern matching uses simple similarity scoring (no ML/neural nets)
- Single power meter only (multi-meter support coming soon)
- Dashboard is basic (full UI coming in v0.5)

---

## Roadmap

### v0.5.0 (Planned)
- Full device management dashboard UI
- Real-time pattern visualization
- Advanced statistics & analytics
- Mobile app integration

### v0.6.0 (Planned)
- Machine learning integration
- Multi-meter support
- Historical trend analysis
- Energy optimization recommendations

### v1.0.0 (Target)
- Production-ready AI detection
- Full cloud optional integration
- Community device signatures
- Professional documentation & videos
