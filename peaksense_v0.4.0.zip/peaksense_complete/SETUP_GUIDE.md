# 🚀 PeakSense Complete Setup Guide

Follow these steps to set up and train PeakSense for automatic device detection.

---

## Phase 1: Installation (5 minutes)

### Step 1.1: Install via HACS

1. **HACS → Integrations → ⋮ → Custom repositories**
2. Add: `https://github.com/BryanGeldof/PeakSense` (type: Integration)
3. **Install PeakSense**
4. **Restart Home Assistant**

### Step 1.2: Add Integration

1. **Settings → Devices & Services → + Add Integration**
2. Search: **PeakSense**
3. Click and **Submit**

### Step 1.3: Verify Sensors

**Developer Tools → States**

You should see:
- ✅ `sensor.peaksense_last_event`
- ✅ `sensor.peaksense_status`
- ✅ `sensor.peaksense_current_device`
- ✅ `sensor.peaksense_detection_confidence`

---

## Phase 2: Setup Automation (5 minutes)

### Step 2.1: Create Power Meter Automation

**Settings → Automations → Create New**

```yaml
alias: Feed power to PeakSense
trigger:
  - platform: state
    entity_id: sensor.YOUR_POWER_METER  # ← CHANGE THIS!
action:
  - service: peaksense.update
    data:
      value: "{{ states('sensor.YOUR_POWER_METER') | float }}"
mode: queued
```

**Important:** Replace `sensor.YOUR_POWER_METER` with your actual power sensor!

Examples:
- `sensor.p1_meter_total_power` (P1 meter)
- `sensor.shelly_power` (Shelly plug)
- `sensor.mqtt_power` (MQTT)

### Step 2.2: Test Automation

1. **Developer Tools → Services**
2. Service: `peaksense.update`
3. Data: `{"value": 900}`
4. Call Service

Repeat with values: 900, 1200, 1500, 300

**Result:** `sensor.peaksense_last_event` should show 1500W

---

## Phase 3: Device Training (20 minutes)

### Step 3.1: Register Device

**Developer Tools → Services**

```yaml
service: peaksense.register_device
data:
  name: "Washing Machine"
  standby_power: 2
  notes: "ASKO W6984 Washing Machine"
```

**Repeat for each device you want to train:**
- Coffee Machine
- Oven
- Dishwasher
- Dryer
- TV
- etc.

### Step 3.2: Record Device Signatures

For EACH device:

1. **Turn on the device**
2. Let it run normally
3. Wait for spike to be detected
4. **Check Developer Tools → States**
5. Find `sensor.peaksense_last_event` → look at the `id` attribute
6. **Call this service:**

```yaml
service: peaksense.record_signature
data:
  event_id: 1          # ← From step 5
  device_id: 1         # ← From Step 3.1 response
```

**Repeat 5-7 times per device** for best accuracy:
- Different usage levels if possible
- Different start times

---

## Phase 4: Verify Detection (5 minutes)

### Step 4.1: Test Recognition

1. **Turn on one of your trained devices**
2. Wait for spike
3. Check: `sensor.peaksense_current_device`
   - Should show device name
   - Check `sensor.peaksense_detection_confidence` (should be 75%+)

### Step 4.2: Improve with Feedback

If detection is wrong:

```yaml
service: peaksense.provide_feedback
data:
  event_id: 42
  device_id: 1
  is_correct: false
```

---

## Phase 5: Advanced Setup (Optional)

### Step 5.1: Create Device Management Automation

For easy device registration:

```yaml
alias: "PeakSense: Register Coffee Machine"
sequence:
  - service: peaksense.register_device
    data:
      name: "Coffee Machine"
      standby_power: 3
      notes: "Delonghi Magnifica"

alias: "PeakSense: Register Washing Machine"
sequence:
  - service: peaksense.register_device
    data:
      name: "Washing Machine"
      standby_power: 2
      notes: "ASKO W6984"
```

### Step 5.2: Standby Power Detection

To automatically detect standby power:

```yaml
alias: Detect Standby Power
trigger:
  - platform: time
    at: "22:00:00"  # Every night
action:
  - service: peaksense.update
    data:
      value: "{{ states('sensor.total_power') | float }}"
  # This gives baseline power without any device running
```

### Step 5.3: Notifications on Detection

```yaml
alias: Notify on Device Detection
trigger:
  - platform: state
    entity_id: sensor.peaksense_current_device
action:
  - service: notify.notify
    data:
      message: "Device detected: {{ states('sensor.peaksense_current_device') }}"
```

---

## Troubleshooting Checklist

| Issue | Solution |
|---|---|
| No spikes detected | Check power meter automation is running |
| Wrong device detected | Need more training (5+ signatures) |
| Low confidence | Thresholds may be wrong (check const.py) |
| Automation not running | Check trigger (state of power sensor) |
| Can't find event ID | Look in `sensor.peaksense_last_event` attributes |
| Device not registering | Check device name doesn't already exist |

---

## Database Inspection

You can view your learning data in `/config/peaksense.db` using SQLite:

```sql
-- See all devices
SELECT * FROM devices;

-- See all recorded signatures
SELECT d.name, s.peak, s.avg, s.duration FROM signatures s
JOIN devices d ON s.device_id = d.id;

-- See detection accuracy
SELECT COUNT(*) FROM detections WHERE is_correct = 1;
```

---

## Tips for Best Results

1. **Train with variety** — Run devices at different power levels
2. **Record multiple** — 5-7 signatures per device
3. **Be consistent** — Always turn devices fully on/off
4. **Use feedback** — Correct mistakes to improve model
5. **Label events** — Use `peaksense.label_event` for manual labeling
6. **Monitor confidence** — Check detection confidence in sensor

---

## Next Steps

- ✅ Create automations for each device
- ✅ Add to your automation routines
- ✅ Build a dashboard to visualize detections
- ✅ Use in energy optimization routines

---

**Congratulations!** Your PeakSense system is now ready! 🎉
