"""Core PeakSense coordinator with device detection."""

import logging
from datetime import datetime

from .detector import SpikeDetector
from .storage import Storage
from .pattern_matcher import PatternMatcher

_LOGGER = logging.getLogger(__name__)


class PeakSenseCore:
    """Main coordinator for PeakSense."""

    def __init__(self):
        self.detector = SpikeDetector()
        self.storage = Storage()
        self.matcher = PatternMatcher()
        self.matcher.storage = self.storage  # Link matcher to storage
        
        self.last_event = None
        self.current_device = None
        self.current_confidence = 0

    def process_value(self, value: float) -> dict:
        """Process a power value and detect spikes/devices."""
        event = self.detector.process(value, datetime.now().isoformat())

        if event:
            # Save event
            event_id = self.storage.save_event(event)
            event['id'] = event_id
            
            # Try to detect device
            devices = self.storage.get_all_devices()
            detection = self.matcher.match_event(event, devices)
            
            # If confident, record detection and update event
            if detection['confidence'] > 0:
                if detection['device_id']:
                    self.storage.update_event_device(
                        event_id,
                        detection['device_id'],
                        detection['confidence']
                    )
                    self.storage.record_detection(
                        event_id,
                        detection['device_id'],
                        detection['confidence']
                    )
                    _LOGGER.info(
                        f"Detected: {detection['device_name']} "
                        f"({detection['confidence']*100:.0f}% confidence)"
                    )
            
            self.last_event = event
            self.current_device = detection['device_name']
            self.current_confidence = detection['confidence']
            
            return event

        return None

    def register_device(self, name: str, standby_power: float = 0, notes: str = "") -> int:
        """Register a new device."""
        device_id = self.storage.create_device(name, standby_power, notes)
        _LOGGER.info(f"Registered device: {name} (ID: {device_id})")
        return device_id

    def record_device_signature(self, device_id: int, event: dict) -> None:
        """Record a spike signature for device learning."""
        self.storage.record_signature(device_id, event)
        _LOGGER.info(f"Recorded signature for device {device_id}: {event['peak']}W peak")

    def auto_detect_standby(self, device_id: int) -> float:
        """
        Get standby power for a device based on before/after readings.
        This should be called after the user performs the standby detection routine.
        """
        device = self.storage.get_device(device_id)
        return device.get('standby_power', 0) if device else 0

    def get_device_stats(self, device_id: int) -> dict:
        """Get statistics for a device."""
        return self.storage.get_device_statistics(device_id)

    def get_all_devices(self) -> list:
        """Get all registered devices."""
        return self.storage.get_all_devices()

    def delete_device(self, device_id: int) -> None:
        """Delete a device."""
        self.storage.delete_device(device_id)
        _LOGGER.info(f"Deleted device {device_id}")

    def update_device(self, device_id: int, **kwargs) -> None:
        """Update device info."""
        self.storage.update_device(device_id, **kwargs)
        _LOGGER.info(f"Updated device {device_id}: {kwargs}")

    def provide_feedback(self, event_id: int, device_id: int, is_correct: bool) -> None:
        """
        User provides feedback on a detection.
        Helps improve the model over time.
        """
        if is_correct:
            # Learn from correct detection
            event = self.storage.get_recent_events(1)[0]
            if event['id'] == event_id:
                self.record_device_signature(device_id, event)
                _LOGGER.info(f"Learning: confirmed {device_id} for event {event_id}")
        else:
            _LOGGER.info(f"Feedback: detection was incorrect for event {event_id}")
