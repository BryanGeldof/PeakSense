"""PeakSense integration with intelligent device detection."""

import json
import logging

from homeassistant.core import HomeAssistant, ServiceCall
from homeassistant.config_entries import ConfigEntry
from homeassistant.components.http import HomeAssistantView

from .coordinator import PeakSenseCore
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up PeakSense from a config entry."""
    _LOGGER.debug("PeakSense: async_setup_entry starting")

    core = PeakSenseCore()
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = core
    _LOGGER.debug("PeakSense: Core initialized")

    # ============================================
    # Service: peaksense.update
    # Push power values in
    # ============================================
    async def handle_update(call: ServiceCall):
        value = float(call.data.get("value", 0))
        _LOGGER.debug(f"PeakSense.update: {value}W")
        core.process_value(value)

    hass.services.async_register(DOMAIN, "update", handle_update)
    _LOGGER.debug("PeakSense: update service registered")

    # ============================================
    # Service: peaksense.register_device
    # Register a new device for learning
    # ============================================
    async def handle_register_device(call: ServiceCall):
        name = str(call.data.get("name", "Unknown"))
        standby_power = float(call.data.get("standby_power", 0))
        notes = str(call.data.get("notes", ""))
        
        device_id = core.register_device(name, standby_power, notes)
        _LOGGER.info(f"Registered device: {name}")

    hass.services.async_register(DOMAIN, "register_device", handle_register_device)
    _LOGGER.debug("PeakSense: register_device service registered")

    # ============================================
    # Service: peaksense.record_signature
    # Record a spike as a device signature
    # ============================================
    async def handle_record_signature(call: ServiceCall):
        event_id = int(call.data.get("event_id"))
        device_id = int(call.data.get("device_id"))
        
        # Get the event from storage
        events = core.storage.get_recent_events(1)
        if events and events[0]['id'] == event_id:
            event = events[0]
            core.record_device_signature(device_id, event)
            _LOGGER.info(f"Recorded signature for device {device_id}")
        else:
            _LOGGER.warning(f"Event {event_id} not found")

    hass.services.async_register(DOMAIN, "record_signature", handle_record_signature)
    _LOGGER.debug("PeakSense: record_signature service registered")

    # ============================================
    # Service: peaksense.label_event
    # Old method - kept for compatibility
    # ============================================
    async def handle_label_event(call: ServiceCall):
        event_id = int(call.data.get("event_id"))
        label = str(call.data.get("label", "unknown"))
        
        core.storage.label_event(event_id, label)
        _LOGGER.info(f"Labeled event {event_id}: {label}")

    hass.services.async_register(DOMAIN, "label_event", handle_label_event)
    _LOGGER.debug("PeakSense: label_event service registered")

    # ============================================
    # Service: peaksense.provide_feedback
    # Train the model with feedback
    # ============================================
    async def handle_provide_feedback(call: ServiceCall):
        event_id = int(call.data.get("event_id"))
        device_id = int(call.data.get("device_id"))
        is_correct = bool(call.data.get("is_correct", False))
        
        core.provide_feedback(event_id, device_id, is_correct)
        status = "correct" if is_correct else "incorrect"
        _LOGGER.info(f"Feedback: event {event_id} was {status}")

    hass.services.async_register(DOMAIN, "provide_feedback", handle_provide_feedback)
    _LOGGER.debug("PeakSense: provide_feedback service registered")

    # ============================================
    # Service: peaksense.update_device
    # Update device settings
    # ============================================
    async def handle_update_device(call: ServiceCall):
        device_id = int(call.data.get("device_id"))
        standby_power = call.data.get("standby_power")
        notes = call.data.get("notes")
        name = call.data.get("name")
        
        kwargs = {}
        if name is not None:
            kwargs['name'] = str(name)
        if standby_power is not None:
            kwargs['standby_power'] = float(standby_power)
        if notes is not None:
            kwargs['notes'] = str(notes)
        
        core.update_device(device_id, **kwargs)
        _LOGGER.info(f"Updated device {device_id}")

    hass.services.async_register(DOMAIN, "update_device", handle_update_device)
    _LOGGER.debug("PeakSense: update_device service registered")

    # ============================================
    # Service: peaksense.delete_device
    # Delete a device
    # ============================================
    async def handle_delete_device(call: ServiceCall):
        device_id = int(call.data.get("device_id"))
        core.delete_device(device_id)
        _LOGGER.info(f"Deleted device {device_id}")

    hass.services.async_register(DOMAIN, "delete_device", handle_delete_device)
    _LOGGER.debug("PeakSense: delete_device service registered")

    # ============================================
    # REST API Endpoints
    # ============================================
    hass.http.register_view(PeakSenseEventsView(core))
    hass.http.register_view(PeakSenseDevicesView(core))
    hass.http.register_view(PeakSenseStatsView(core))
    _LOGGER.debug("PeakSense: REST API endpoints registered")

    # Load sensors
    await hass.config_entries.async_forward_entry_setups(entry, ["sensor"])
    _LOGGER.debug("PeakSense: sensors loaded")

    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    unload_ok = await hass.config_entries.async_unload_platforms(entry, ["sensor"])
    if unload_ok:
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok


# ============================================
# REST API Views
# ============================================

class PeakSenseEventsView(HomeAssistantView):
    """GET /api/peaksense/events - Recent events"""

    url = "/api/peaksense/events"
    name = "api:peaksense:events"
    requires_auth = True

    def __init__(self, core: PeakSenseCore):
        self._core = core

    async def get(self, request):
        from aiohttp.web import Response
        try:
            events = self._core.storage.get_recent_events(100)
            return Response(
                text=json.dumps(events),
                content_type="application/json",
            )
        except Exception as e:
            _LOGGER.error(f"API error: {e}", exc_info=True)
            return Response(
                text=json.dumps({"error": str(e)}),
                status=500,
                content_type="application/json",
            )


class PeakSenseDevicesView(HomeAssistantView):
    """GET /api/peaksense/devices - List all devices"""

    url = "/api/peaksense/devices"
    name = "api:peaksense:devices"
    requires_auth = True

    def __init__(self, core: PeakSenseCore):
        self._core = core

    async def get(self, request):
        from aiohttp.web import Response
        try:
            devices = self._core.get_all_devices()
            
            # Add stats for each device
            devices_with_stats = []
            for device in devices:
                stats = self._core.get_device_stats(device['id'])
                device['stats'] = stats
                devices_with_stats.append(device)
            
            return Response(
                text=json.dumps(devices_with_stats),
                content_type="application/json",
            )
        except Exception as e:
            _LOGGER.error(f"API error: {e}", exc_info=True)
            return Response(
                text=json.dumps({"error": str(e)}),
                status=500,
                content_type="application/json",
            )


class PeakSenseStatsView(HomeAssistantView):
    """GET /api/peaksense/stats - Overall statistics"""

    url = "/api/peaksense/stats"
    name = "api:peaksense:stats"
    requires_auth = True

    def __init__(self, core: PeakSenseCore):
        self._core = core

    async def get(self, request):
        from aiohttp.web import Response
        try:
            accuracy = self._core.storage.get_accuracy_stats()
            return Response(
                text=json.dumps(accuracy),
                content_type="application/json",
            )
        except Exception as e:
            _LOGGER.error(f"API error: {e}", exc_info=True)
            return Response(
                text=json.dumps({"error": str(e)}),
                status=500,
                content_type="application/json",
            )
